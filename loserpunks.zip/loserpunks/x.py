import json
import copy

with open("loserpunk.json",'r') as load_f:
    loserpunks = json.load(load_f)

with open("punk.json",'r') as load_f2:
    punk = json.load(load_f2)

for i in range(667):
    with open(str(i)+".json",'w') as f:
        newpunk = copy.copy(punk)
        newpunk['image'] = punk['image'] + loserpunks[i]["hash"]
        newpunk['name'] = punk['name'] + str(i)
        json.dump(newpunk, f)
        f.close()


print ('done')
